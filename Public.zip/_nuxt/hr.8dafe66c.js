import{_ as e,o as c,c as r}from"./entry.431318b1.js";const o={};function t(n,s){return c(),r("hr")}const a=e(o,[["render",t]]);export{a as default};
