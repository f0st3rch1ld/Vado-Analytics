import{q as n,C as e}from"./entry.431318b1.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
